"use client";

import Link from 'next/link';
import Image from 'next/image';
import { Instagram, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center gap-3 mb-4">
              <div className="relative w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/logo-1762348918309.png"
                  alt="Berry n' Crumbs Logo"
                  width={40}
                  height={40}
                  className="object-cover" />
              </div>
              <span className="text-xl font-bold text-primary">Berry n' Crumbs</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Freshly baked goods made with love and the finest ingredients.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-muted-foreground hover:text-primary transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/orders" className="text-muted-foreground hover:text-primary transition-colors">
                  Track Orders
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-muted-foreground">Cakes</li>
              <li className="text-muted-foreground">Pastries</li>
              <li className="text-muted-foreground">Breads</li>
              <li className="text-muted-foreground">Cookies</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4" />
                +91 98765 43210
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Instagram className="h-4 w-4" />
                <a 
                  href="https://www.instagram.com/berryncrumbs_" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-primary transition-colors"
                >
                  @berryncrumbs_
                </a>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground !whitespace-pre-line">
                <MapPin className="h-4 w-4" />
                Bhilwara, Rajasthan
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Berry n' Crumbs. All rights reserved.
        </div>
      </div>
    </footer>
  );
}