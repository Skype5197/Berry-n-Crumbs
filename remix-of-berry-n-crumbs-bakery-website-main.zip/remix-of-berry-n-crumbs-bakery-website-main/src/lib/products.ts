export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
}

export const products: Product[] = [
  // Cakes
  {
    id: '1',
    name: 'Chocolate Truffle Cake',
    price: 850,
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&q=80',
    category: 'Cakes',
    description: 'Rich chocolate cake with truffle frosting',
  },
  {
    id: '2',
    name: 'Black Forest Cake',
    price: 750,
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&q=80',
    category: 'Cakes',
    description: 'Classic black forest with cherries',
  },
  {
    id: '3',
    name: 'Red Velvet Cake',
    price: 900,
    image: 'https://images.unsplash.com/photo-1586788680434-30d324b2d46f?w=600&q=80',
    category: 'Cakes',
    description: 'Velvety red cake with cream cheese frosting',
  },
  {
    id: '4',
    name: 'Strawberry Delight Cake',
    price: 800,
    image: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=600&q=80',
    category: 'Cakes',
    description: 'Fresh strawberry cake with whipped cream',
  },

  // Pastries
  {
    id: '5',
    name: 'Blueberry Cheesecake',
    price: 180,
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&q=80',
    category: 'Pastries',
    description: 'Creamy cheesecake with blueberry topping',
  },
  {
    id: '6',
    name: 'Chocolate Éclair',
    price: 120,
    image: 'https://images.unsplash.com/photo-1612203985729-70726954388c?w=600&q=80',
    category: 'Pastries',
    description: 'French pastry with chocolate glaze',
  },
  {
    id: '7',
    name: 'Fruit Tart',
    price: 150,
    image: 'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=600&q=80',
    category: 'Pastries',
    description: 'Buttery tart with fresh seasonal fruits',
  },
  {
    id: '8',
    name: 'Tiramisu',
    price: 200,
    image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=600&q=80',
    category: 'Pastries',
    description: 'Italian coffee-flavored dessert',
  },

  // Breads
  {
    id: '9',
    name: 'Sourdough Loaf',
    price: 120,
    image: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=600&q=80',
    category: 'Breads',
    description: 'Artisan sourdough bread',
  },
  {
    id: '10',
    name: 'Multigrain Bread',
    price: 100,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&q=80',
    category: 'Breads',
    description: 'Healthy multigrain loaf',
  },
  {
    id: '11',
    name: 'Garlic Bread',
    price: 80,
    image: 'https://images.unsplash.com/photo-1619519525965-00f0c9ae9bf1?w=600&q=80',
    category: 'Breads',
    description: 'Freshly baked garlic bread with herbs',
  },
  {
    id: '12',
    name: 'Croissant',
    price: 60,
    image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&q=80',
    category: 'Breads',
    description: 'Buttery French croissant',
  },

  // Cookies
  {
    id: '13',
    name: 'Chocolate Chip Cookies',
    price: 250,
    image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=600&q=80',
    category: 'Cookies',
    description: 'Classic cookies with chocolate chips (pack of 6)',
  },
  {
    id: '14',
    name: 'Butter Cookies',
    price: 200,
    image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&q=80',
    category: 'Cookies',
    description: 'Crispy butter cookies (pack of 8)',
  },
  {
    id: '15',
    name: 'Oatmeal Raisin Cookies',
    price: 220,
    image: 'https://images.unsplash.com/photo-1590080876547-1bc315c86c41?w=600&q=80',
    category: 'Cookies',
    description: 'Healthy oatmeal cookies with raisins (pack of 6)',
  },
  {
    id: '16',
    name: 'Macarons',
    price: 400,
    image: 'https://images.unsplash.com/photo-1569864358642-9d1684040f43?w=600&q=80',
    category: 'Cookies',
    description: 'Colorful French macarons (pack of 6)',
  },
];
