import Razorpay from 'razorpay';

let razorpayInstanceCache: Razorpay | null = null;

function getRazorpayInstance(): Razorpay {
  if (razorpayInstanceCache) {
    return razorpayInstanceCache;
  }

  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    throw new Error('Missing Razorpay API credentials');
  }

  razorpayInstanceCache = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });

  return razorpayInstanceCache;
}

export const razorpayInstance = new Proxy({} as Razorpay, {
  get(target, prop) {
    const instance = getRazorpayInstance();
    return (instance as any)[prop];
  }
});