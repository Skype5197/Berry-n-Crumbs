import crypto from 'crypto';
import { razorpayInstance } from './razorpay';
import { RazorpayOrder, PaymentVerification } from './razorpay-types';

// Create order
export async function createRazorpayOrder(
  amount: number,
  currency: string = 'INR',
  receipt: string = `receipt_${Date.now()}`,
  notes?: Record<string, string>
): Promise<RazorpayOrder> {
  try {
    const order = await razorpayInstance.orders.create({
      amount: Math.round(amount * 100), // Convert to paise
      currency,
      receipt,
      notes: notes || {},
    });
    return order as unknown as RazorpayOrder;
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    throw new Error('Failed to create payment order');
  }
}

// Verify payment signature
export function verifyPaymentSignature(
  orderId: string,
  paymentId: string,
  signature: string
): PaymentVerification {
  try {
    const secret = process.env.RAZORPAY_KEY_SECRET as string;
    const message = `${orderId}|${paymentId}`;
    
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(message)
      .digest('hex');

    const verified = expectedSignature === signature;

    return {
      orderId,
      paymentId,
      signature,
      verified,
    };
  } catch (error) {
    console.error('Error verifying signature:', error);
    return {
      orderId,
      paymentId,
      signature,
      verified: false,
    };
  }
}

// Fetch payment status
export async function getPaymentStatus(
  paymentId: string
): Promise<{ status: string; captured: boolean }> {
  try {
    const payment = await razorpayInstance.payments.fetch(paymentId);
    return {
      status: payment.status as string,
      captured: payment.captured as boolean,
    };
  } catch (error) {
    console.error('Error fetching payment status:', error);
    throw new Error('Failed to fetch payment status');
  }
}
