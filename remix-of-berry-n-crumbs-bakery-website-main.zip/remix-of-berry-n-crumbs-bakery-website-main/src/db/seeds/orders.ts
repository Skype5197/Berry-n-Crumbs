import { db } from '@/db';
import { orders } from '@/db/schema';

async function main() {
    const sampleOrders = [
        {
            orderId: 'ORD123ABC',
            userEmail: 'priya.sharma@gmail.com',
            userName: 'Priya Sharma',
            phone: '+91-9876543210',
            address: '23, MG Road, Koramangala',
            city: 'Bangalore',
            pincode: '560034',
            items: JSON.stringify([
                { name: 'Chocolate Truffle Cake (1kg)', quantity: 1, price: 850 },
                { name: 'Blueberry Muffins', quantity: 4, price: 160 }
            ]),
            subtotal: 1010,
            deliveryFee: 50,
            total: 1060,
            status: 'Processing',
            paymentMethod: 'UPI',
            createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD456DEF',
            userEmail: 'rahul.kumar@outlook.com',
            userName: 'Rahul Kumar',
            phone: '+91-8765432109',
            address: '45, Jayanagar 4th Block',
            city: 'Bangalore',
            pincode: '560011',
            items: JSON.stringify([
                { name: 'Black Forest Cake (500g)', quantity: 1, price: 550 },
                { name: 'Garlic Bread', quantity: 2, price: 120 },
                { name: 'Croissants', quantity: 6, price: 300 }
            ]),
            subtotal: 970,
            deliveryFee: 50,
            total: 1020,
            status: 'Out for Delivery',
            paymentMethod: 'Credit Card',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD789GHI',
            userEmail: 'anjali.patel@yahoo.in',
            userName: 'Anjali Patel',
            phone: '+91-9123456789',
            address: '12/A, Sector 15, Vashi',
            city: 'Mumbai',
            pincode: '400703',
            items: JSON.stringify([
                { name: 'Pineapple Pastry', quantity: 3, price: 270 },
                { name: 'Whole Wheat Bread', quantity: 2, price: 80 }
            ]),
            subtotal: 350,
            deliveryFee: 50,
            total: 400,
            status: 'Delivered',
            paymentMethod: 'Cash on Delivery',
            createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD234JKL',
            userEmail: 'vikram.singh@gmail.com',
            userName: 'Vikram Singh',
            phone: '+91-9988776655',
            address: '78, Rajouri Garden',
            city: 'Delhi',
            pincode: '110027',
            items: JSON.stringify([
                { name: 'Red Velvet Cake (1kg)', quantity: 1, price: 950 },
                { name: 'Chocolate Chip Cookies', quantity: 12, price: 240 }
            ]),
            subtotal: 1190,
            deliveryFee: 50,
            total: 1240,
            status: 'Processing',
            paymentMethod: 'Debit Card',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD567MNO',
            userEmail: 'neha.gupta@gmail.com',
            userName: 'Neha Gupta',
            phone: '+91-8877665544',
            address: '34, Banjara Hills',
            city: 'Hyderabad',
            pincode: '500034',
            items: JSON.stringify([
                { name: 'Vanilla Cupcakes', quantity: 8, price: 320 },
                { name: 'Danish Pastry', quantity: 4, price: 280 }
            ]),
            subtotal: 600,
            deliveryFee: 50,
            total: 650,
            status: 'Out for Delivery',
            paymentMethod: 'UPI',
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD890PQR',
            userEmail: 'arjun.reddy@outlook.com',
            userName: 'Arjun Reddy',
            phone: '+91-7766554433',
            address: '56, T Nagar',
            city: 'Chennai',
            pincode: '600017',
            items: JSON.stringify([
                { name: 'Butterscotch Cake (500g)', quantity: 1, price: 500 },
                { name: 'Almond Cookies', quantity: 10, price: 250 },
                { name: 'Fruit Tart', quantity: 2, price: 180 }
            ]),
            subtotal: 930,
            deliveryFee: 50,
            total: 980,
            status: 'Processing',
            paymentMethod: 'Credit Card',
            createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD345STU',
            userEmail: 'kavya.iyer@gmail.com',
            userName: 'Kavya Iyer',
            phone: '+91-9876123456',
            address: '89, Koregaon Park',
            city: 'Pune',
            pincode: '411001',
            items: JSON.stringify([
                { name: 'Strawberry Shortcake', quantity: 1, price: 650 },
                { name: 'Multigrain Bread', quantity: 1, price: 60 }
            ]),
            subtotal: 710,
            deliveryFee: 50,
            total: 760,
            status: 'Out for Delivery',
            paymentMethod: 'UPI',
            createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        },
        {
            orderId: 'ORD678VWX',
            userEmail: 'rohan.mehta@yahoo.in',
            userName: 'Rohan Mehta',
            phone: '+91-8765123456',
            address: '23, Salt Lake, Sector 5',
            city: 'Kolkata',
            pincode: '700091',
            items: JSON.stringify([
                { name: 'Chocolate Eclair', quantity: 6, price: 360 },
                { name: 'French Baguette', quantity: 2, price: 120 },
                { name: 'Brownie', quantity: 4, price: 240 }
            ]),
            subtotal: 720,
            deliveryFee: 50,
            total: 770,
            status: 'Delivered',
            paymentMethod: 'Cash on Delivery',
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        },
    ];

    await db.insert(orders).values(sampleOrders);
    
    console.log('✅ Orders seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});