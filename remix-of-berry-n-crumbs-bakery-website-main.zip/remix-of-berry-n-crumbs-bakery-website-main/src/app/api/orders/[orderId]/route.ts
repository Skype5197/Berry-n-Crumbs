import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { orders } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ orderId: string }> }
) {
  try {
    const { orderId } = await context.params;

    if (!orderId) {
      return NextResponse.json(
        { 
          error: 'Order ID is required',
          code: 'MISSING_ORDER_ID'
        },
        { status: 400 }
      );
    }

    const order = await db.select()
      .from(orders)
      .where(eq(orders.orderId, orderId))
      .limit(1);

    if (order.length === 0) {
      return NextResponse.json(
        { 
          error: 'Order not found',
          code: 'ORDER_NOT_FOUND'
        },
        { status: 404 }
      );
    }

    return NextResponse.json(order[0], { status: 200 });
  } catch (error: any) {
    console.error('GET error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + error.message 
      },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ orderId: string }> }
) {
  try {
    const { orderId } = await context.params;

    if (!orderId) {
      return NextResponse.json(
        { 
          error: 'Order ID is required',
          code: 'MISSING_ORDER_ID'
        },
        { status: 400 }
      );
    }

    const body = await request.json();
    const { status } = body;

    if (!status) {
      return NextResponse.json(
        { 
          error: 'Status field is required',
          code: 'MISSING_STATUS'
        },
        { status: 400 }
      );
    }

    const existingOrder = await db.select()
      .from(orders)
      .where(eq(orders.orderId, orderId))
      .limit(1);

    if (existingOrder.length === 0) {
      return NextResponse.json(
        { 
          error: 'Order not found',
          code: 'ORDER_NOT_FOUND'
        },
        { status: 404 }
      );
    }

    const updatedOrder = await db.update(orders)
      .set({
        status: status.trim(),
        updatedAt: new Date().toISOString()
      })
      .where(eq(orders.orderId, orderId))
      .returning();

    if (updatedOrder.length === 0) {
      return NextResponse.json(
        { 
          error: 'Failed to update order',
          code: 'UPDATE_FAILED'
        },
        { status: 500 }
      );
    }

    return NextResponse.json(updatedOrder[0], { status: 200 });
  } catch (error: any) {
    console.error('PATCH error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + error.message 
      },
      { status: 500 }
    );
  }
}