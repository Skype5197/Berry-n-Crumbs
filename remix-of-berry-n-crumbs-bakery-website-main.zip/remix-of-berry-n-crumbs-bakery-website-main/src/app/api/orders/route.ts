import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { orders } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      orderId,
      userEmail,
      userName,
      phone,
      address,
      city,
      pincode,
      items,
      subtotal,
      total,
      paymentMethod,
      deliveryFee,
      status
    } = body;

    // Validate required fields
    if (!orderId) {
      return NextResponse.json(
        { error: 'Order ID is required', code: 'MISSING_ORDER_ID' },
        { status: 400 }
      );
    }

    if (!userEmail) {
      return NextResponse.json(
        { error: 'User email is required', code: 'MISSING_USER_EMAIL' },
        { status: 400 }
      );
    }

    if (!userName) {
      return NextResponse.json(
        { error: 'User name is required', code: 'MISSING_USER_NAME' },
        { status: 400 }
      );
    }

    if (!phone) {
      return NextResponse.json(
        { error: 'Phone number is required', code: 'MISSING_PHONE' },
        { status: 400 }
      );
    }

    if (!address) {
      return NextResponse.json(
        { error: 'Address is required', code: 'MISSING_ADDRESS' },
        { status: 400 }
      );
    }

    if (!city) {
      return NextResponse.json(
        { error: 'City is required', code: 'MISSING_CITY' },
        { status: 400 }
      );
    }

    if (!pincode) {
      return NextResponse.json(
        { error: 'Pincode is required', code: 'MISSING_PINCODE' },
        { status: 400 }
      );
    }

    if (!items) {
      return NextResponse.json(
        { error: 'Items are required', code: 'MISSING_ITEMS' },
        { status: 400 }
      );
    }

    if (subtotal === undefined || subtotal === null) {
      return NextResponse.json(
        { error: 'Subtotal is required', code: 'MISSING_SUBTOTAL' },
        { status: 400 }
      );
    }

    if (total === undefined || total === null) {
      return NextResponse.json(
        { error: 'Total is required', code: 'MISSING_TOTAL' },
        { status: 400 }
      );
    }

    if (!paymentMethod) {
      return NextResponse.json(
        { error: 'Payment method is required', code: 'MISSING_PAYMENT_METHOD' },
        { status: 400 }
      );
    }

    // Sanitize inputs
    const sanitizedOrderId = orderId.trim();
    const sanitizedUserEmail = userEmail.trim().toLowerCase();
    const sanitizedUserName = userName.trim();
    const sanitizedPhone = phone.trim();
    const sanitizedAddress = address.trim();
    const sanitizedCity = city.trim();
    const sanitizedPincode = pincode.trim();
    const sanitizedPaymentMethod = paymentMethod.trim();

    // Prepare insert data with defaults and timestamps
    const now = new Date().toISOString();
    const insertData = {
      orderId: sanitizedOrderId,
      userEmail: sanitizedUserEmail,
      userName: sanitizedUserName,
      phone: sanitizedPhone,
      address: sanitizedAddress,
      city: sanitizedCity,
      pincode: sanitizedPincode,
      items: typeof items === 'string' ? items : JSON.stringify(items),
      subtotal,
      deliveryFee: deliveryFee ?? 50,
      total,
      status: status ?? 'Processing',
      paymentMethod: sanitizedPaymentMethod,
      createdAt: now,
      updatedAt: now
    };

    // Insert into database
    const newOrder = await db.insert(orders)
      .values(insertData)
      .returning();

    return NextResponse.json(newOrder[0], { status: 201 });
  } catch (error: any) {
    console.error('POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error.message },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');

    if (email) {
      // Get orders for specific user by email
      const userOrders = await db.select()
        .from(orders)
        .where(eq(orders.userEmail, email.trim().toLowerCase()))
        .orderBy(desc(orders.createdAt));

      return NextResponse.json(userOrders, { status: 200 });
    }

    // Get all orders for admin dashboard
    const allOrders = await db.select()
      .from(orders)
      .orderBy(desc(orders.createdAt));

    return NextResponse.json(allOrders, { status: 200 });
  } catch (error: any) {
    console.error('GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error.message },
      { status: 500 }
    );
  }
}