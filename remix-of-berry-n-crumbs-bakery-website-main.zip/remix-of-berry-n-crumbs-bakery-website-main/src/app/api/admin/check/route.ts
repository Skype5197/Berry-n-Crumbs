import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { user } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { auth } from '@/lib/auth';
import { headers } from 'next/headers';

export async function GET(request: NextRequest) {
  try {
    const session = await auth.api.getSession({ headers: await headers() });

    if (!session || !session.user) {
      return NextResponse.json({
        isAdmin: false,
        authenticated: false
      }, { status: 200 });
    }

    const userRecord = await db.select()
      .from(user)
      .where(eq(user.id, session.user.id))
      .limit(1);

    if (userRecord.length === 0) {
      return NextResponse.json({
        isAdmin: false,
        authenticated: false
      }, { status: 200 });
    }

    const currentUser = userRecord[0];
    const isAdmin = currentUser.role === 'admin';

    return NextResponse.json({
      isAdmin,
      authenticated: true,
      user: {
        id: currentUser.id,
        name: currentUser.name,
        email: currentUser.email,
        role: currentUser.role
      }
    }, { status: 200 });

  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({
      isAdmin: false,
      authenticated: false
    }, { status: 200 });
  }
}