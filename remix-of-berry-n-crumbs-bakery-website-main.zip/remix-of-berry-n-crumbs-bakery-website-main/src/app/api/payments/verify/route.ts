import { NextRequest, NextResponse } from 'next/server';
import { verifyPaymentSignature, getPaymentStatus } from '@/lib/payment-utils';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { orderId, paymentId, signature } = body;

    if (!orderId || !paymentId || !signature) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Verify signature
    const verification = verifyPaymentSignature(orderId, paymentId, signature);

    if (!verification.verified) {
      return NextResponse.json(
        { error: 'Payment signature verification failed' },
        { status: 400 }
      );
    }

    // Check payment status
    const paymentStatus = await getPaymentStatus(paymentId);

    if (paymentStatus.status !== 'captured' && !paymentStatus.captured) {
      return NextResponse.json(
        { error: 'Payment not captured' },
        { status: 400 }
      );
    }

    // Payment verified successfully
    return NextResponse.json(
      {
        success: true,
        orderId,
        paymentId,
        status: paymentStatus.status,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Payment verification error:', error);
    return NextResponse.json(
      { error: 'Payment verification failed' },
      { status: 500 }
    );
  }
}
