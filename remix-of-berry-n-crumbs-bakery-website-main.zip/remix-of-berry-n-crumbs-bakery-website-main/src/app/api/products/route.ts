import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { products, user } from '@/db/schema';
import { eq, desc, like, and } from 'drizzle-orm';
import { auth } from '@/lib/auth';
import { headers } from 'next/headers';

const VALID_CATEGORIES = ['Cakes', 'Pastries', 'Breads', 'Cookies'];

async function checkAdminAuth(request: NextRequest) {
  try {
    const session = await auth.api.getSession({ headers: await headers() });
    
    if (!session) {
      return { authorized: false, status: 401, error: 'Authentication required' };
    }

    const userId = session.user?.id;
    if (!userId) {
      return { authorized: false, status: 401, error: 'Invalid session' };
    }

    const userRecord = await db.select()
      .from(user)
      .where(eq(user.id, userId))
      .limit(1);

    if (userRecord.length === 0) {
      return { authorized: false, status: 401, error: 'User not found' };
    }

    if (userRecord[0].role !== 'admin') {
      return { authorized: false, status: 403, error: 'Admin access required' };
    }

    return { authorized: true, userId };
  } catch (error) {
    console.error('Auth check error:', error);
    return { authorized: false, status: 500, error: 'Authentication error' };
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const limit = Math.min(parseInt(searchParams.get('limit') ?? '50'), 100);
    const offset = parseInt(searchParams.get('offset') ?? '0');
    const search = searchParams.get('search');
    const category = searchParams.get('category');

    let query = db.select().from(products);

    const conditions = [];

    if (search) {
      conditions.push(like(products.name, `%${search}%`));
    }

    if (category) {
      if (!VALID_CATEGORIES.includes(category)) {
        return NextResponse.json({
          error: `Invalid category. Must be one of: ${VALID_CATEGORIES.join(', ')}`,
          code: 'INVALID_CATEGORY'
        }, { status: 400 });
      }
      conditions.push(eq(products.category, category));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const results = await query
      .orderBy(desc(products.createdAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json(results, { status: 200 });
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authCheck = await checkAdminAuth(request);
    if (!authCheck.authorized) {
      return NextResponse.json({
        error: authCheck.error,
        code: authCheck.status === 403 ? 'FORBIDDEN' : 'UNAUTHORIZED'
      }, { status: authCheck.status });
    }

    const body = await request.json();
    const { name, price, image, category, description, inStock } = body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json({
        error: 'Product name is required',
        code: 'MISSING_NAME'
      }, { status: 400 });
    }

    if (!price || typeof price !== 'number' || price <= 0 || !Number.isInteger(price)) {
      return NextResponse.json({
        error: 'Valid positive integer price is required',
        code: 'INVALID_PRICE'
      }, { status: 400 });
    }

    if (!image || typeof image !== 'string' || image.trim().length === 0) {
      return NextResponse.json({
        error: 'Product image URL is required',
        code: 'MISSING_IMAGE'
      }, { status: 400 });
    }

    if (!category || typeof category !== 'string') {
      return NextResponse.json({
        error: 'Product category is required',
        code: 'MISSING_CATEGORY'
      }, { status: 400 });
    }

    if (!VALID_CATEGORIES.includes(category)) {
      return NextResponse.json({
        error: `Category must be one of: ${VALID_CATEGORIES.join(', ')}`,
        code: 'INVALID_CATEGORY'
      }, { status: 400 });
    }

    if (!description || typeof description !== 'string' || description.trim().length === 0) {
      return NextResponse.json({
        error: 'Product description is required',
        code: 'MISSING_DESCRIPTION'
      }, { status: 400 });
    }

    const sanitizedName = name.trim();
    const sanitizedImage = image.trim();
    const sanitizedDescription = description.trim();
    const stockStatus = inStock !== undefined ? Boolean(inStock) : true;

    const newProduct = await db.insert(products)
      .values({
        name: sanitizedName,
        price,
        image: sanitizedImage,
        category,
        description: sanitizedDescription,
        inStock: stockStatus,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      })
      .returning();

    return NextResponse.json(newProduct[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const authCheck = await checkAdminAuth(request);
    if (!authCheck.authorized) {
      return NextResponse.json({
        error: authCheck.error,
        code: authCheck.status === 403 ? 'FORBIDDEN' : 'UNAUTHORIZED'
      }, { status: authCheck.status });
    }

    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({
        error: 'Valid product ID is required',
        code: 'INVALID_ID'
      }, { status: 400 });
    }

    const productId = parseInt(id);

    const existingProduct = await db.select()
      .from(products)
      .where(eq(products.id, productId))
      .limit(1);

    if (existingProduct.length === 0) {
      return NextResponse.json({
        error: 'Product not found',
        code: 'NOT_FOUND'
      }, { status: 404 });
    }

    const body = await request.json();
    const { name, price, image, category, description, inStock } = body;

    const updates: any = {
      updatedAt: new Date().toISOString()
    };

    if (name !== undefined) {
      if (typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({
          error: 'Product name must be a non-empty string',
          code: 'INVALID_NAME'
        }, { status: 400 });
      }
      updates.name = name.trim();
    }

    if (price !== undefined) {
      if (typeof price !== 'number' || price <= 0 || !Number.isInteger(price)) {
        return NextResponse.json({
          error: 'Price must be a positive integer',
          code: 'INVALID_PRICE'
        }, { status: 400 });
      }
      updates.price = price;
    }

    if (image !== undefined) {
      if (typeof image !== 'string' || image.trim().length === 0) {
        return NextResponse.json({
          error: 'Image URL must be a non-empty string',
          code: 'INVALID_IMAGE'
        }, { status: 400 });
      }
      updates.image = image.trim();
    }

    if (category !== undefined) {
      if (!VALID_CATEGORIES.includes(category)) {
        return NextResponse.json({
          error: `Category must be one of: ${VALID_CATEGORIES.join(', ')}`,
          code: 'INVALID_CATEGORY'
        }, { status: 400 });
      }
      updates.category = category;
    }

    if (description !== undefined) {
      if (typeof description !== 'string' || description.trim().length === 0) {
        return NextResponse.json({
          error: 'Description must be a non-empty string',
          code: 'INVALID_DESCRIPTION'
        }, { status: 400 });
      }
      updates.description = description.trim();
    }

    if (inStock !== undefined) {
      updates.inStock = Boolean(inStock);
    }

    const updatedProduct = await db.update(products)
      .set(updates)
      .where(eq(products.id, productId))
      .returning();

    return NextResponse.json(updatedProduct[0], { status: 200 });
  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const authCheck = await checkAdminAuth(request);
    if (!authCheck.authorized) {
      return NextResponse.json({
        error: authCheck.error,
        code: authCheck.status === 403 ? 'FORBIDDEN' : 'UNAUTHORIZED'
      }, { status: authCheck.status });
    }

    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({
        error: 'Valid product ID is required',
        code: 'INVALID_ID'
      }, { status: 400 });
    }

    const productId = parseInt(id);

    const existingProduct = await db.select()
      .from(products)
      .where(eq(products.id, productId))
      .limit(1);

    if (existingProduct.length === 0) {
      return NextResponse.json({
        error: 'Product not found',
        code: 'NOT_FOUND'
      }, { status: 404 });
    }

    const deletedProduct = await db.delete(products)
      .where(eq(products.id, productId))
      .returning();

    return NextResponse.json({
      message: 'Product deleted successfully',
      product: deletedProduct[0]
    }, { status: 200 });
  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + (error instanceof Error ? error.message : 'Unknown error')
    }, { status: 500 });
  }
}