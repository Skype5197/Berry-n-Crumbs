"use client";

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingCart, RefreshCw, PackageOpen, Plus, Minus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
  inStock: boolean;
}

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { addToCart, cart, updateQuantity, removeFromCart } = useCart();

  const categories = ['All', 'Cakes', 'Pastries', 'Breads', 'Cookies'];

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/products');
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      } else {
        toast.error('Failed to load products');
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Error loading products');
    } finally {
      setLoading(false);
    }
  };
  
  const getCartQuantity = (productId: number) => {
    const cartItem = cart.find(item => item.id === productId.toString());
    return cartItem?.quantity || 0;
  };

  const handleAddToCart = (product: Product) => {
    addToCart({
      id: product.id.toString(),
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      description: product.description
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleIncrement = (product: Product) => {
    const quantity = getCartQuantity(product.id);
    updateQuantity(product.id.toString(), quantity + 1);
  };

  const handleDecrement = (productId: number) => {
    const quantity = getCartQuantity(productId);
    if (quantity > 1) {
      updateQuantity(productId.toString(), quantity - 1);
    } else {
      removeFromCart(productId.toString());
      toast.success('Item removed from cart');
    }
  };

  const handleRemove = (productId: number, productName: string) => {
    removeFromCart(productId.toString());
    toast.success(`${productName} removed from cart`);
  };
  
  const filteredProducts = selectedCategory === 'All' 
    ? products.filter(p => p.inStock)
    : products.filter(p => p.category === selectedCategory && p.inStock);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 py-12">
        <div className="container px-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Products</h1>
            <p className="text-lg text-muted-foreground">
              Discover our delicious selection of freshly baked goods
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center mb-12">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList>
                {categories.map((category) => (
                  <TabsTrigger key={category} value={category}>
                    {category}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>

          {/* Loading State */}
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-20">
              <PackageOpen className="h-24 w-24 mx-auto text-muted-foreground mb-6" />
              <h2 className="text-2xl font-semibold mb-4">No products available</h2>
              <p className="text-muted-foreground mb-6">
                {selectedCategory === 'All' 
                  ? 'Check back soon for delicious treats!'
                  : `No ${selectedCategory.toLowerCase()} available at the moment.`
                }
              </p>
            </div>
          ) : (
            /* Products Grid */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => {
                const cartQuantity = getCartQuantity(product.id);
                const isInCart = cartQuantity > 0;

                return (
                  <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <CardHeader className="p-0">
                      <div className="relative h-56 w-full">
                        <Image
                          src={product.image}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        {isInCart && (
                          <div className="absolute top-2 right-2">
                            <Badge className="bg-primary text-primary-foreground">
                              {cartQuantity} in cart
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="mb-2">
                        {product.category}
                      </Badge>
                      <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {product.description}
                      </p>
                      <p className="text-2xl font-bold text-primary">₹{product.price}</p>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      {!isInCart ? (
                        <Button 
                          className="w-full" 
                          onClick={() => handleAddToCart(product)}
                        >
                          <ShoppingCart className="mr-2 h-4 w-4" />
                          Add to Cart
                        </Button>
                      ) : (
                        <div className="w-full space-y-2">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleDecrement(product.id)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <div className="flex-1 text-center font-semibold">
                              {cartQuantity}
                            </div>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleIncrement(product)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <Button
                            variant="destructive"
                            size="sm"
                            className="w-full"
                            onClick={() => handleRemove(product.id, product.name)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Remove from Cart
                          </Button>
                        </div>
                      )}
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}